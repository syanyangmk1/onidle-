﻿
// My9View.cpp: CMy9View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "My9.h"
#endif

#include "My9Doc.h"
#include "My9View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMy9View

IMPLEMENT_DYNCREATE(CMy9View, CView)

BEGIN_MESSAGE_MAP(CMy9View, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
    ON_WM_TIMER()
END_MESSAGE_MAP()

// CMy9View 생성/소멸

CMy9View::CMy9View() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CMy9View::~CMy9View()
{
}

BOOL CMy9View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CMy9View 그리기


// CMy9View 인쇄

BOOL CMy9View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CMy9View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CMy9View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}


// CMy9View 진단

#ifdef _DEBUG
void CMy9View::AssertValid() const
{
	CView::AssertValid();
}

void CMy9View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy9Doc* CMy9View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy9Doc)));
	return (CMy9Doc*)m_pDocument;
}
#endif //_DEBUG


// CMy9View 메시지 처리기


void CMy9View::OnInitialUpdate()
{
    CView::OnInitialUpdate();

    // 1초 간격으로 타이머 설정 (ID: 1, 1000ms)
    SetTimer(1, 1000, NULL); // 타이머 ID 1번, 1초(1000ms) 간격

    // 랜덤한 타원의 개수 초기화
}

void CMy9View::OnTimer(UINT_PTR nIDEvent)
{
    if (nIDEvent == 1) // 타이머 ID가 1인 경우
    {

        // 화면 갱신 요청 (OnDraw를 호출)
        Invalidate();
    }

    CView::OnTimer(nIDEvent); // 기본 타이머 처리
}

void CMy9View::OnDraw(CDC* pDC)
{
    CMy9Doc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    if (!pDoc)
        return;

    CRect r;
    GetClientRect(&r); // 클라이언트 영역의 크기를 가져옵니다.

    // 랜덤한 수의 타원 그리기
    for (int i = 0; i < 100; ++i)
    {
        // 임의의 사각형 생성
        CRect rr(rand() % r.Width(), rand() % r.Height(),
            rand() % r.Width(), rand() % r.Height());

        // 임의의 색상 선택
        COLORREF rc = RGB(rand() % 256, rand() % 256, rand() % 256);

        // 브러시 생성 (임의의 색상으로 타원을 채우기 위해)
        CBrush brush(rc);
        CBrush* pOldBrush = pDC->SelectObject(&brush);

        // 타원 그리기 (사각형 rr 내에 내접하는 타원)
        pDC->Ellipse(rr);

        // 브러시 해제
        pDC->SelectObject(pOldBrush);
    }
}